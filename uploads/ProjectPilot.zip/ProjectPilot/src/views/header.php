<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ProjectPilot</title>
    <link rel="stylesheet" href="/ProjectPilot/public/css/styles.css">
</head>
<body>
    <header>
        <h1>ProjectPilot</h1>
        <nav>
            <ul>
                <li><a href="/ProjectPilot/public/index.php">Home</a></li>
                <li><a href="/ProjectPilot/public/dashboard.php">Dashboard</a></li>
                <li><a href="/ProjectPilot/public/contact.php">Contact</a></li>
                <li><a href="/ProjectPilot/public/about.php">About</a></li>
            </ul>
        </nav>
    </header>