<?php
// This is the footer section of the ProjectPilot application
?>

<footer>
    <div class="container">
        <p>&copy; <?php echo date("Y"); ?> ProjectPilot. All rights reserved.</p>
        <ul>
            <li><a href="about.php">About Us</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="privacy.php">Privacy Policy</a></li>
        </ul>
    </div>
</footer>

<script src="public/js/scripts.js"></script>