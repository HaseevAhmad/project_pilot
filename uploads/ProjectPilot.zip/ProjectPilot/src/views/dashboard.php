<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <?php include 'header.php'; ?>

    <div class="dashboard">
        <h1>Welcome to the ProjectPilot Dashboard</h1>
        <p>Your role: <?php echo $_SESSION['user_role']; ?></p>

        <?php if ($_SESSION['user_role'] == 'Admin'): ?>
            <h2>Admin Panel</h2>
            <p>Manage projects, users, and settings.</p>
            <!-- Admin specific functionalities -->
        <?php elseif ($_SESSION['user_role'] == 'Supervisor'): ?>
            <h2>Supervisor Panel</h2>
            <p>Review project submissions and provide feedback.</p>
            <!-- Supervisor specific functionalities -->
        <?php elseif ($_SESSION['user_role'] == 'Student'): ?>
            <h2>Student Panel</h2>
            <p>Submit your projects and view feedback.</p>
            <!-- Student specific functionalities -->
        <?php else: ?>
            <p>Invalid role. Please contact support.</p>
        <?php endif; ?>
    </div>

    <?php include 'footer.php'; ?>
</body>
</html>