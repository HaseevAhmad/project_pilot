# ProjectPilot - Final-Year Project Management System

## Overview
ProjectPilot is a web-based application designed to facilitate the management of final-year projects for students, supervisors, and administrators. The system allows users to submit projects, review submissions, and provide feedback, all within a user-friendly interface.

## Features
- User authentication and role-based access (Admin, Supervisor, Student)
- Project submission and review process
- Feedback mechanism for project submissions
- Dashboard for users to view their projects and statuses
- Clean and responsive user interface

## Installation Instructions

### Prerequisites
- XAMPP installed on your local machine
- Basic knowledge of PHP, HTML, CSS, and JavaScript

### Step-by-Step Setup

1. **Install XAMPP**: 
   - Download and install XAMPP from the official website.
   - Start the Apache and MySQL services from the XAMPP control panel.

2. **Create Project Directory**: 
   - Navigate to the `htdocs` folder in your XAMPP installation directory (e.g., `C:\xampp\htdocs`).
   - Create a new folder named `ProjectPilot`.

3. **Set Up Project Structure**: 
   - Inside the `ProjectPilot` folder, create the following directory structure:
     ```
     ProjectPilot
     ├── public
     ├── src
     ├── .htaccess
     ├── composer.json
     └── README.md
     ```

4. **Create Necessary Files**: 
   - Create the files as per the project tree structure outlined in the project description.

5. **Database Configuration**:
   - Open `src/config/database.php` and set up your database connection using PDO.
   - Create a database in phpMyAdmin (accessible via `http://localhost/phpmyadmin`) and configure the connection settings accordingly.

6. **Install Composer**: 
   - If you need any PHP libraries, install Composer from the official website.
   - Run `composer install` in the `ProjectPilot` directory to install dependencies listed in `composer.json`.

7. **Set Up .htaccess**: 
   - Configure the `.htaccess` file to enable URL rewriting. Add rules to handle clean URLs for your application.

8. **Develop Application Logic**:
   - Implement the logic in `src/controllers/ProjectController.php` to handle project submissions, reviews, and feedback.
   - Define the data structure and database interactions in `src/models/Project.php`.

9. **Create Views**: 
   - Design the user interface in the view files (`header.php`, `footer.php`, `dashboard.php`) to provide a seamless experience for Admins, Supervisors, and Students.

10. **Add Styles and Scripts**: 
    - Write CSS in `public/css/styles.css` for styling and JavaScript in `public/js/scripts.js` for client-side functionality.

11. **Test the Application**: 
    - Open a web browser and navigate to `http://localhost/ProjectPilot/public/index.php` to test the application. Ensure all functionalities work as expected.

12. **Documentation**: 
    - Update this README.md file with detailed instructions on how to set up and use the ProjectPilot system.

## Usage
- Access the application through your web browser.
- Follow the on-screen instructions to register, log in, and manage projects based on your user role.

## Contributing
Contributions are welcome! Please feel free to submit a pull request or open an issue for any enhancements or bug fixes.

## License
This project is open-source and available under the MIT License.