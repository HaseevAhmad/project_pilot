<?php
// Entry point of the application

// Autoload classes using Composer
require_once '../vendor/autoload.php';

// Start a session
session_start();

// Include necessary files
require_once '../src/config/database.php';
require_once '../src/controllers/ProjectController.php';

// Initialize the database connection
$database = new Database();
$db = $database->getConnection();

// Initialize the ProjectController
$projectController = new ProjectController($db);

// Handle routing
$requestUri = $_SERVER['REQUEST_URI'];
switch ($requestUri) {
    case '/':
        // Load the dashboard view
        require_once '../src/views/dashboard.php';
        break;
    case '/submit':
        // Handle project submission
        $projectController->submitProject();
        break;
    case '/review':
        // Handle project review
        $projectController->reviewProject();
        break;
    default:
        // Load a 404 page or redirect
        http_response_code(404);
        echo "404 Not Found";
        break;
}
?>